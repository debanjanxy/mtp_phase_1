import shutil

import requests

url = 'https://maps.googleapis.com/maps/api/staticmap?center=19.0883595,72.82652380000002&size=640x640&zoom=19&maptype=satellite'
response = requests.get(url, stream=True)
with open('img.png', 'wb') as out_file:
    shutil.copyfileobj(response.raw, out_file)
del response