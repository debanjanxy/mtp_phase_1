function initAutocomplete() {
  var mapOptions = new google.maps.Map(document.getElementById('map'), {
    center: {lat: 19.397, lng: 76.644},
    zoom: 19,
    mapTypeId: google.maps.MapTypeId.SATELLITE
  });

  map = new google.maps.Map(document.getElementById("map"), mapOptions);

  // Create the search box and link it to the UI element.
  var input = document.getElementById('pac-input');
  var searchBox = new google.maps.places.SearchBox(input);

  // Bias the SearchBox results towards current map's viewport.
  mapOptions.addListener('bounds_changed', function() {
    searchBox.setBounds(mapOptions.getBounds());
  });
    
  var geocoder = new google.maps.Geocoder();

  document.getElementById('search').addEventListener('click', function() {
    geocodeAddress(geocoder, mapOptions);
  });
}

function geocodeAddress(geocoder, resultsMap) {
  var address = document.getElementById('pac-input').value;
  geocoder.geocode({'address': address}, function(results, status) {
  if (status === 'OK') {
    resultsMap.setCenter(results[0].geometry.location);
    var marker = new google.maps.Marker({
      map: resultsMap,
      position: results[0].geometry.location
    });
  } else {
      alert("Please type the name of the place!");
    }
  });
}