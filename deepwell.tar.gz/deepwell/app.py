#!/usr/bin/python2.7

from flask import Flask, render_template,request
from scipy.misc import imsave, imread, imresize, imsave
import numpy as np
import keras.models
from keras.models import load_model
import re
import base64
import sys 
import os
sys.path.append(os.path.abspath("./model"))
from load import * 
import shutil
import requests

app = Flask(__name__)
global model, graph
model, graph = init()

	
#save the bas64 png string as a png image in local storage
def convertImage(imgData):
	imgstr = re.search(r'base64,(.*)',imgData).group(1)
	with open('input.png','wb') as output:
		output.write(imgstr.decode('base64'))

def downloadImage(imgUrl):
		response = requests.get(imgUrl, stream=True)
		with open('input.png', 'wb') as out_file:
			shutil.copyfileobj(response.raw, out_file)
		del response

#Models will be applied in this function 
def modelFunction(img):
    	return img


@app.route('/')
def index():
	return render_template("index.html")

@app.route('/predict/',methods=['GET','POST'])
def predict():
	imgUrl = request.get_data() # bas64 png string of image
	print "IMAGE_URL: "+imgUrl
	downloadImage(imgUrl)
	x = imread('input.png',mode='RGB') # L means the pixel values are 8 bits, i.e, black & white
	modelFunction(x)
	imsave('output.png',x)
	with open('output.png','rb') as imgFile:
		string = base64.b64encode(imgFile.read())
	outputPngStr = "data:image/png;base64,"+string
	with graph.as_default():
		# out = model.predict(x)
		response = outputPngStr
		return response	
	

if __name__ == "__main__":
	port = int(os.environ.get('PORT', 8000))
	app.run(host='0.0.0.0', port=port)
